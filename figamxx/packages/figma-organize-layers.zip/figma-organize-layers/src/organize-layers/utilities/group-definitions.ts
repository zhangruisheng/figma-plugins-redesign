export const groupDefinitions = [
  { text: '1st /', value: 1 },
  { text: '2nd /', value: 2 },
  { text: '3rd /', value: 3 },
  { text: '4th /', value: 4 },
  { text: '5th /', value: 5 }
]
