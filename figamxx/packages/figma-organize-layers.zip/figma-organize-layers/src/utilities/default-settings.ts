export const defaultSettings = {
  combineSingleLayerGroups: true,
  groupDefinition: 1,
  horizontalSpace: 100,
  verticalSpace: 50
}
