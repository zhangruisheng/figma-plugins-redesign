import { render } from '@create-figma-plugin/ui'

import { OrganizeLayers } from './components/organize-layers'

export default render(OrganizeLayers)
